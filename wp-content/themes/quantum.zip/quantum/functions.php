<?php

/**
 * Quantum functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Quantum
 */

if (!defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

if (!function_exists('quantum_setup')) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function quantum_setup()
	{
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Quantum, use a find and replace
		 * to change 'quantum' to the name of your theme in all the template files.
		 */
		load_theme_textdomain('quantum', get_template_directory() . '/languages');

		// Add default posts and comments RSS feed links to head.
		add_theme_support('automatic-feed-links');

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support('title-tag');

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support('post-thumbnails');

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__('Header', 'quantum'),
				'menu-2' => esc_html__('Footer', 'quantum'),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'quantum_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support('customize-selective-refresh-widgets');

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action('after_setup_theme', 'quantum_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function quantum_content_width()
{
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters('quantum_content_width', 640);
}
add_action('after_setup_theme', 'quantum_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function quantum_widgets_init()
{
	register_sidebar(
		array(
			'name'          => esc_html__('Sidebar', 'quantum'),
			'id'            => 'sidebar-1',
			'description'   => esc_html__('Add widgets here.', 'quantum'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action('widgets_init', 'quantum_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function quantum_scripts()
{
	wp_enqueue_style('quantum-style', get_stylesheet_uri(), array(), _S_VERSION);
	wp_style_add_data('quantum-style', 'rtl', 'replace');

	wp_enqueue_script('quantum-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'quantum_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}


/**
 * Добавляет блок для ввода контактных данных
 */
function mytheme_customize_register($wp_customize)
{
	/*
	Добавляем секцию в настройки темы
	*/
	$wp_customize->add_section(
		// ID
		'data_site_section',
		// Массив аргументов
		array(
			'title' => 'Контактные данные в шапке сайта',
			'capability' => 'edit_theme_options',
			'description' => "Тут можно указать контактные данные"
		)
	);
	/*
	Добавляем поле ссылки телефона site_telephone-link
	*/
	$wp_customize->add_setting(
		// ID
		'site_telephone-link',
		// Массив аргументов
		array(
			'default' => '',
			'type' => 'option'
		)
	);
	$wp_customize->add_control(
		// ID
		'site_telephone-link_control',
		// Массив аргументов
		array(
			'type' => 'text',
			'label' => "Ссылка телефона (номер в формате: 89209993322)",
			'section' => 'data_site_section',
			'settings' => 'site_telephone-link'
		)
	);
	/*
	Добавляем поле телефона site_telephone
	*/
	$wp_customize->add_setting(
		// ID
		'site_telephone',
		// Массив аргументов
		array(
			'default' => '',
			'type' => 'option'
		)
	);
	$wp_customize->add_control(
		// ID
		'site_telephone_control',
		// Массив аргументов
		array(
			'type' => 'text',
			'label' => "Текст с телефона",
			'section' => 'data_site_section',
			'settings' => 'site_telephone'
		)
	);
	/*
	Добавляем поле почты site_mail
	*/
	$wp_customize->add_setting(
		// ID
		'site_mail',
		// Массив аргументов
		array(
			'default' => '',
			'type' => 'option'
		)
	);
	$wp_customize->add_control(
		// ID
		'site_mail_control',
		// Массив аргументов
		array(
			'type' => 'text',
			'label' => "Почта",
			'section' => 'data_site_section',
			'settings' => 'site_mail'
		)
	);



	/* Дополнительные телефон и почта */
	/*
	Добавляем поле ссылки телефона site_telephone-link-2
	*/
	$wp_customize->add_setting(
		// ID
		'site_telephone-link-2',
		// Массив аргументов
		array(
			'default' => '',
			'type' => 'option'
		)
	);
	$wp_customize->add_control(
		// ID
		'site_telephone-link-2_control',
		// Массив аргументов
		array(
			'type' => 'text',
			'label' => "Ссылка телефона-2 (номер в формате: 89209993322)",
			'section' => 'data_site_section',
			'settings' => 'site_telephone-link-2'
		)
	);
	/*
	Добавляем поле телефона site_telephone
	*/
	$wp_customize->add_setting(
		// ID
		'site_telephone-2',
		// Массив аргументов
		array(
			'default' => '',
			'type' => 'option'
		)
	);
	$wp_customize->add_control(
		// ID
		'site_telephone-2_control',
		// Массив аргументов
		array(
			'type' => 'text',
			'label' => "Текст с телефона-2",
			'section' => 'data_site_section',
			'settings' => 'site_telephone-2'
		)
	);
	/*
	Добавляем поле почты site_mail
	*/
	$wp_customize->add_setting(
		// ID
		'site_mail-2',
		// Массив аргументов
		array(
			'default' => '',
			'type' => 'option'
		)
	);
	$wp_customize->add_control(
		// ID
		'site_mail-2_control',
		// Массив аргументов
		array(
			'type' => 'text',
			'label' => "Почта-2",
			'section' => 'data_site_section',
			'settings' => 'site_mail-2'
		)
	);
}
add_action('customize_register', 'mytheme_customize_register');
